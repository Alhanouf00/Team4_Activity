//
//  CollectionViewCell.swift
//  activiteDemo
//
//  Created by T Aljohni on 13/03/1443 AH.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var image: UIImageView!
    @IBOutlet weak var lbl: UILabel!
    
    @IBOutlet weak var width: NSLayoutConstraint!
    
    @IBOutlet weak var height: NSLayoutConstraint!
}

//
//  movesApi.swift
//  activiteDemo
//
//  Created by T Aljohni on 13/03/1443 AH.
//

import Foundation
import Alamofire


class MovieApi{
   
    static func getAllMovie (completionHandler:@escaping (_ data: Data?, _ response: URLResponse?, _ error: Error?) -> Void)
        {

        let url = URL(string: "https://api.tvmaze.com/shows")
               
        let session = URLSession.shared
        
        let task = session.dataTask(with: url!, completionHandler: completionHandler)

              
               task.resume()
              
       }
        
    }

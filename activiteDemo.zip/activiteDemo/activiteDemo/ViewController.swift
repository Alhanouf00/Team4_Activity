//
//  ViewController.swift
//  activiteDemo
//
//  Created by T Aljohni on 13/03/1443 AH.
//

import UIKit
import Kingfisher


class ViewController: UICollectionViewController {

    
    var movies :[Movie?] = []
    
    
    @IBOutlet var collection: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        movieApi()
        // Do any additional setup after loading the view.
    }
    // tell the collection view how many cells to make

    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return movies.count
    }
    // make a cell for each cell index path
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
     let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "movieCell", for: indexPath as IndexPath) as! CollectionViewCell
        cell.lbl.text? = movies[indexPath.row]!.name
        let url = URL(string: movies[indexPath.row]!.image.medium)
        cell.image.kf.setImage(with: url, placeholder: UIImage(named: ""))
//                cell.height.constant = movies[indexPath.row]!.size.height
                cell.width.constant = self.view.frame.size.width / 2 - 50
      
     return cell
    }
    
    
    func movieApi(){
        MovieApi.getAllMovie(completionHandler:
                    {
                      data, response, error in
                            do {
                                 guard let mydata = data else {return}
                                let postResult = try JSONDecoder().decode([Movie].self ,from: mydata)
                                self.movies = postResult
                                print(self.movies)
                                DispatchQueue.main.async(){self.collection.reloadData()}
                               }
                    catch {print(error)}
                                })
    }
           
          

}

